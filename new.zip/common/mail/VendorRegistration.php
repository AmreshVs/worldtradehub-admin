<?php

/* @var $name string */

?>

<p style="margin:0px 0px 10px 0px;">
   <b>Vendor Created Successfully</b>,
</p>
<p style="margin:0px 0px 5px 0px;">
    The Login Credentials are<br>
    <b style="color:#000; font-size:15px">Username:</b><p><?= $username ?></p>
    <b style="color:#000; font-size:15px">Password:</b><p><?= $password ?></p>
</p>