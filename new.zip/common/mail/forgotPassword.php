<?php

/* @var $name string */

?>

<p style="margin:0px 0px 10px 0px;">
    Dear <b><?= $name?></b>,
</p>
<p style="margin:0px 0px 5px 0px;">
    We have received your forgot password
    request.<b
    style="color:#000; font-size:15px"><a href= <?= $resetLink ?>> Click Here </a></b>.
    to reset your password.
</p>