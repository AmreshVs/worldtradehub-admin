<?php
namespace common\models;

use common\models\base\BaseStates;

/**
 * Class States
 * @package common\models
 */
class States extends BaseStates
{
}
