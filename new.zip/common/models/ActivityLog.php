<?php

namespace common\models;

use common\models\base\BaseActivityLog;

/**
 * Class ActivityLog
 * @package common\models
 */
class ActivityLog extends BaseActivityLog
{
}
