<?php

use yii\db\Connection;

$host  = '192.168.1.179';

return [];