<?php
namespace api\modules\v1\models;

/**
 * Class AdminUser
 * @package api\modules\v1\models
 */
class AdminUser extends \common\models\AdminUser
{
}
