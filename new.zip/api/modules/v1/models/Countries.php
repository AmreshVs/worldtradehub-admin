<?php
namespace api\modules\v1\models;

/**
 * Class Countries
 * @package api\modules\v1\models
 */
class Countries extends \common\models\Countries
{
}
