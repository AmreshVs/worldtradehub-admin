<?php
namespace api\modules\v1\models;

/**
 * Class ActivityLog
 * @package api\modules\v1\models
 */
class ActivityLog extends \common\models\ActivityLog
{
}
