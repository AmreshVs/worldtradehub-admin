<?php
namespace backend\models;

/**
 * Class Countries
 * @package backend\models
 */
class Countries extends \common\models\Countries
{
}
