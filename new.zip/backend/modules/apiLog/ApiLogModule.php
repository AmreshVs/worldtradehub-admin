<?php

namespace backend\modules\apiLog;

use yii\base\Module;

/**
 * Class ApiLogModule
 * @package backend\modules\apiLog
 */
class ApiLogModule extends Module
{
}