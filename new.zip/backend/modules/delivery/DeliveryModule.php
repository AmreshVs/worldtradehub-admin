<?php

namespace backend\modules\delivery;

use yii\base\Module;

/**
 * Class TranslationModule
 * @package backend\modules\deliveryBoy
 */
class DeliveryModule extends Module
{
}