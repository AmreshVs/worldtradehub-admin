<?php

namespace backend\modules\translation;

use yii\base\Module;

/**
 * Class TranslationModule
 * @package backend\modules\translation
 */
class TranslationModule extends Module
{
}