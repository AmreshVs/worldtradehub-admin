<?php
return [
    'adminEmail' => 'admin@example.com',
    'postsPerPage' => 20
];
