<?php
namespace frontend\models;

/**
 * Class ActivityLog
 * @package frontend\models
 */
class ActivityLog extends \common\models\ActivityLog
{
}
