<?php
namespace frontend\models;

/**
 * Class Countries
 * @package frontend\models
 */
class Countries extends \common\models\Countries
{
}
