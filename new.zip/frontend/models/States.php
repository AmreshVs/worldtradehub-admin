<?php
namespace frontend\models;

/**
 * Class States
 * @package frontend\models
 */
class States extends \common\models\States
{
}
