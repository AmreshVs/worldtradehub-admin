<?php

use yii\db\Connection;

return [
    'components' => [
        'db' => [
            'class' => Connection::class,
             'dsn' => 'mysql:host=148.72.88.28;dbname=worldtradehub',
            'username' => 'worldtradehub_dev',
            'password' => 'VWpx+W?E7YB}',
            'charset' => 'utf8',
        ],
       
    ],
];
