<?php

use yii\gii\Module;

return [
    'bootstrap' => ['gii'],
    'modules' => [
        'gii' => Module::class,
    ],
];
