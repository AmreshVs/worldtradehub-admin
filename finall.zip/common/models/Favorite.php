<?php
namespace common\models;

use common\models\base\BaseFavorite;

/**
 * Class Favorite
 * @package common\models
 */
class Favorite extends BaseFavorite
{
}
