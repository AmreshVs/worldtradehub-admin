<?php
namespace common\models;

use common\models\base\BaseCities;

/**
 * Class Cities
 * @package common\models
 */
class Cities extends BaseCities
{
}
