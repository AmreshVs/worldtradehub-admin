<?php
namespace common\models;

use common\models\base\BaseCountries;

/**
 * Class Countries
 * @package common\models
 */
class Countries extends BaseCountries
{
}
