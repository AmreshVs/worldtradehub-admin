<?php

/* @var $name string */

?>

<p style="margin:0px 0px 10px 0px;">
   <b>Hi <?= $username ?></b>,
</p>
<p style="margin:0px 0px 5px 0px;">
    Glad to inform that  You have been successfully registered as a customer in tabaogo.com  
</p>