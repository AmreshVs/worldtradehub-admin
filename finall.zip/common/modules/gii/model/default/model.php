<?php
echo "<?php\n";
?>
namespace <?= $ns ?>;

/**
 * Class <?= "$className\n" ?>
 * @package <?= "$ns\n" ?>
 */
class <?= $className ?> extends \common\models\<?= "$className\n" ?>
{
}
