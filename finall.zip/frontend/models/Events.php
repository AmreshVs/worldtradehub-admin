<?php
namespace frontend\models;

/**
 * Class Events
 * @package frontend\models
 */
class Events extends \common\models\Events
{
}
