<?php
namespace frontend\models;

/**
 * Class Role
 * @package frontend\models
 */
class Role extends \common\models\Role
{
}
