<?php
namespace frontend\models;

/**
 * Class AdminUser
 * @package frontend\models
 */
class AdminUser extends \common\models\AdminUser
{
}
