<?php
namespace frontend\models;

/**
 * Class Ticket
 * @package frontend\models
 */
class Ticket extends \common\models\Ticket
{
}
