<?php
namespace frontend\models;

/**
 * Class Favorite
 * @package frontend\models
 */
class Favorite extends \common\models\Favorite
{
}
