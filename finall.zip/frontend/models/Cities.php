<?php
namespace frontend\models;

/**
 * Class Cities
 * @package frontend\models
 */
class Cities extends \common\models\Cities
{
}
