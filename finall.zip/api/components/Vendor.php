<?php

namespace api\components;

use yii\web\User;

/**
 * Class Vendor
 * @package api\components
 */
class Vendor extends User
{

}