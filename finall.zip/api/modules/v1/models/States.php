<?php
namespace api\modules\v1\models;

/**
 * Class States
 * @package api\modules\v1\models
 */
class States extends \common\models\States
{
}
