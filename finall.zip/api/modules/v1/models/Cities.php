<?php
namespace api\modules\v1\models;

/**
 * Class Cities
 * @package api\modules\v1\models
 */
class Cities extends \common\models\Cities
{
}
