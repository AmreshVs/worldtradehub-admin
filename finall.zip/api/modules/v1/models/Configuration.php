<?php
namespace api\modules\v1\models;

/**
 * Class Configuration
 * @package api\modules\v1\models
 */
class Configuration extends \common\models\Configuration
{
}
