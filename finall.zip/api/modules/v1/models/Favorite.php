<?php
namespace api\modules\v1\models;

/**
 * Class Favorite
 * @package api\modules\v1\models
 */
class Favorite extends \common\models\Favorite
{
}
