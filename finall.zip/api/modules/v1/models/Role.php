<?php
namespace api\modules\v1\models;

/**
 * Class Role
 * @package api\modules\v1\models
 */
class Role extends \common\models\Role
{
}
