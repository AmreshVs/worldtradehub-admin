<?php
/**
 * Created by IntelliJ IDEA.
 * User: developer
 * Date: 7/7/17
 * Time: 9:35 AM
 */

namespace backend\modules\translation\models;

/**
 * Class Message
 * @package backend\modules\translation\models
 */
class Message extends \common\models\Message
{

}