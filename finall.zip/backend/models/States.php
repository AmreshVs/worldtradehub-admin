<?php
namespace backend\models;

/**
 * Class States
 * @package backend\models
 */
class States extends \common\models\States
{
}
