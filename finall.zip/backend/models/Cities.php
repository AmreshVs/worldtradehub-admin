<?php
namespace backend\models;

/**
 * Class Cities
 * @package backend\models
 */
class Cities extends \common\models\Cities
{
}
