<?php

/* @var $this \yii\web\View */
/* @var $content string */

use backend\assets\AppAsset;
use yii\helpers\Html;
use backend\models\Configuration;
use yii\helpers\Url;

AppAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
    <head>
        <meta charset="<?= Yii::$app->charset ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <?= Html::csrfMetaTags() ?>
        <title><?= Html::encode($this->title) ?></title>
        <?php $this->head() ?>
    </head>
    <body class="skin-default-dark fixed-layout">
        <?php $this->beginBody() ?>
            <section id="wrapper" class="error-page not_found_page">
                <div class="error-box">
                    <div class="error-body text-center">

 <img src="/backend/web/theme/images/404.gif">
    <h3 class="text-uppercase">Page Not Found !</h3>
   <p class="text-muted m-t-30 m-b-30"><?= Yii::t('backend', 'No worries! It\'s just a 404 page. Just navigate to any existing page.'); ?></p>
                        <?= Html::a('Back to Home', Url::to(['dashboard/']), ['class' => 'btn btn-info btn-rounded waves-effect waves-light m-b-40']) ?>
                    </div>
                </div>
            </section>
        <?php $this->endBody() ?>
    </body>
</html>
<?php $this->endPage() ?>